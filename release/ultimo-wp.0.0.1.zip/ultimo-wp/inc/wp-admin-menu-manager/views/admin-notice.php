<div class="updated">
    <p><?php _e('Keep calm! This menu is only available for high-level users (Administrators). Users with lower capabilities won\'t be able to see or edit a thing here!.', $this->text_domain); ?></p>
</div>